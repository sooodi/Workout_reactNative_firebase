import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  KeyboardAvoidingView,
} from "react-native";
import { stringHelper } from "@utility/helper/stringHelper";
import { FormInput, Header, Loading } from "@component/common";
import { useNavigation } from "@react-navigation/native";
import * as IntensityActions from '@store/Intensity/IntensityActions';
import { useDispatch, connect, useSelector } from "react-redux";
import { Button } from "react-native-elements";
import { Colors } from "@utility/constants/Colors";
import { valueConstant } from "@utility/constants/valueConstant";
import { showAlert } from "@utility/helper/functionHelper";
import * as areaActions from "@store/area/areaActions";
import navigationService from "@navigation/navigationService";

const Intensity = (props) =>  {

  const dispatch = useDispatch();
  const [selectedIntensity, setSelectedIntensity] = useState(1);
  const [userData, setUserData] = useState( useSelector((state) => state.user));
  const navigation = useNavigation();
  const {intensityListArray, intensityLoading} = props;

  useEffect(() => {
    dispatch(IntensityActions.getIntensityList());

  }, []);

  const selectIntensity=(e,i)=>{
    setSelectedIntensity(i)
    dispatch(IntensityActions.selectIntensity(e));
  }
  return (
    <View style={styles.container}>
      <Header
        centerText={stringHelper.screens.intensity}
        leftPress={() => navigation.goBack()}
        leftIcon={stringHelper.icons.return}
        leftText={stringHelper.back}
      />
      <KeyboardAvoidingView style={styles.exercises} behavior="position">
        {/*<FormInput*/}
        {/*  value={currentWeight.toString()}*/}
        {/*  placeholderText={stringHelper.auth.auth}*/}
        {/*  onChangeText={(value) => setCurrentWeight(value)}*/}
        {/*  autoCapitalize="none"*/}
        {/*  keyboardType="email-address"*/}
        {/*  autoCorrect={false}*/}
        {/*/>*/}
        <View style={{flexDirection:'row'}}>
        <Text style={[styles.text,{backgroundColor:'blue'}]}>{userData.weight}</Text>
        <Text style={[styles.text,{backgroundColor:'blue'}]}>{userData.targetWeight}</Text>
        </View>
        <View style={{alignItems:'center'}}>
        {intensityLoading ? (
          <Loading />
        ) : (
          intensityListArray.map((e, i) => (
            <TouchableOpacity
              onPress={() => selectIntensity(e,i)}
              style={styles.loginBtn}>
              <Text style={[styles.text,{backgroundColor:selectedIntensity===i ?'blue':'#ee557f'}]}>{e.name}</Text>
              <Image
                style={styles.image}
                source={require('../../assets/image/next_arrow.png')}
              />
            </TouchableOpacity>
          ))
          )}
        </View>
      </KeyboardAvoidingView>
      <Button
        onPress={ () =>   navigationService.navigate('Workoutdays')}
        buttonStyle={[
          styles.buttonStyle,
          {
            backgroundColor: Colors.BUTTON_DEACTIVE_COLOR,
          },
        ]}
        containerStyle={{ alignItems: 'center' }}
        titleStyle={{
          color:  Colors.FORMINPUT_COLOR,
        }}
        title={stringHelper.next}

      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    // alignItems: 'center',
    // justifyContent: 'center',

  },
  buttonStyle: {
    width: valueConstant.formItemWidth,
    height: valueConstant.formItemHeight,
    borderRadius: 10,
    borderWidth: 0,
    marginTop: 24, //36-12
  },
  exercises: {
    alignItems: 'center',
    justifyContent:'center',
    marginTop:25,
    marginLeft:50,
  },
  image:{
    width:25,
    height:25,
  },

  loginBtn: {
    marginEnd:25,
    width: 90,
    borderRadius: 40,
    marginVertical:16,
    height: 50,
    flexDirection:'row',
    alignItems: 'center',
    justifyContent: 'center',
    // backgroundColor: '#97d8ef',
  },
  text:{
    width: 140,
    borderRadius: 20,
    height: 50,
    textAlign:'center',
    paddingTop:15,
    marginEnd:20,
    // marginTop:10,
    alignItems: 'center',
    justifyContent: 'center',
    color:'white',
    backgroundColor: '#ee557f',

  },
});

const mapStateToProps = (state) => {
  return {
    intensityListArray: state.intens.intensityList,
    intensityLoading: state.intens.loading,
  };
};

export default connect(mapStateToProps)(Intensity);
