import CheckBox from '@react-native-community/checkbox';

import { FlatList, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React, { useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { Button } from "react-native-elements";
import navigationService from "@navigation/navigationService";
import { Colors } from "@utility/constants/Colors";
import { stringHelper } from "@utility/helper/stringHelper";
import { valueConstant } from "@utility/constants/valueConstant";
import * as areaActions from "@store/area/areaActions";
import * as userAction from "@store/user/userAction";
import { RadioButton } from "@component/common/RadioButton";
export  const Workoutdays=()=>  {

  const dispatch = useDispatch();
  const [days, setDays] = useState(
    [ {index:0,selected:false,time: '1 day'},
      {index:1,selected:false,time: '2 days'},
      {index:2,selected:false,time: '3 days'}] );
  let rr=useSelector((state) => state.intens.intensityData)
  let user=useSelector((state) => state.user)


  useEffect(() => {
    const arrayTemp = days.map((e) => {
   //   if( e.index +1 === user.day_at_week)
      return {
        ...e, selected: e.index +1 === user.day_at_week
      }

    })
    //console.log("rrrrr",arrayTemp)
  //  setDays(arrayTemp)

  }, []);
  const setCheckBox=(index)=> {

    const arrayTemp = days.map((e) => {

      return {
        ...e, selected: e.index === index
      }
    })

    setDays(arrayTemp)

  }
  const UpdateAndStartWorkout=()=>{
    let selectedDay= days.filter((e) => {
        if(e.selected===true)
          return e

    })

    dispatch(userAction.updateProfile({day_at_week:selectedDay.index+1})).then(
      data=>{
        const arrayTemp = data.map((e) => {
          return {
            ...e, selected: false
          }
        })
        console.log("hi",JSON.stringify(arrayTemp))
        setSelectedArea(arrayTemp)
        setSelectedLoading(false)
      }
    )

  }
  function getAppointmentTimePage() {
    return (
      <View>
        <Text style={[styles.title, { marginTop: 50 }]}>How often would you like to work?</Text>
        <FlatList
          data={days}
          keyExtractor={(times) => times.id}
          renderItem={({ item,  index }) => {
            console.log("days",JSON.stringify(days[index].selected))
            return (
              <TouchableOpacity
                onPress={()=>setCheckBox(index)}
                style={styles.containerTime}>
                <Text >{item.time}</Text>
                <RadioButton
                  selected={days[index].selected} />
              </TouchableOpacity>
            );
          }}
        />
        <Button
          onPress={ () =>  UpdateAndStartWorkout()}
          buttonStyle={[
            styles.buttonStyle,
            {
              backgroundColor: Colors.BUTTON_DEACTIVE_COLOR,
            },
          ]}
          containerStyle={{ alignItems: 'center' }}
          titleStyle={{
            color:  Colors.FORMINPUT_COLOR,
          }}
          title={stringHelper.next}

        />
      </View>
    );
  }

    return (
      <View>
        {getAppointmentTimePage()}
      </View>
    )

};
const styles = StyleSheet.create({
  title:{
    alignItems: 'center',
    justifyContent: 'center',
    marginStart:100,
    width: 200,
    height:50,
  },
  containerTime:{
    flexDirection:"row",
    marginStart:150,
    marginTop:50,
    width:90,
    height:40,
  },
  buttonStyle: {
    width: valueConstant.formItemWidth,
    height: valueConstant.formItemHeight,
    borderRadius: 10,
    borderWidth: 0,
    marginTop: 24, //36-12
  },

});
const mapStateToProps = (state) => {
  return {
    intensityListArray: state.intens.intensityList,
    intensityLoading: state.intens.loading,
  };
};

export default connect(mapStateToProps)(Workoutdays);
